import customtkinter as ctk
import time
from core import updater, tweaks

class WinCustomizerApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.current_version = "1.2.0" # Po updatu zde bude 1.1.0
        
        self.title(f"WinCustomizer Pro v{self.current_version}")
        self.geometry("1000x600")
        ctk.set_appearance_mode("dark")

        # UI Setup
        self.setup_sidebar()
        self.main_content = ctk.CTkFrame(self, fg_color="#1a1a1a", corner_radius=15)
        self.main_content.pack(side="right", fill="both", expand=True, padx=20, pady=20)
        
        # Kontrola updatu
        self.after(2000, self.check_for_updates)

    def setup_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        
        ctk.CTkLabel(self.sidebar, text="WIN CUSTOMIZER", font=("Impact", 24)).pack(pady=30)
        
        ctk.CTkButton(self.sidebar, text="Basic Tweaks", fg_color="transparent", anchor="w",
                       command=self.show_basic_page).pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.sidebar, text="Advanced", fg_color="transparent", anchor="w",
                       command=self.show_advanced_page).pack(fill="x", padx=10, pady=5)

    def check_for_updates(self):
        data = updater.check_for_update(self.current_version)
        if data:
            self.show_update_panel(data)

    def show_update_panel(self, data):
        self.upd_panel = ctk.CTkFrame(self, fg_color="#2b2b2b", border_color="orange", border_width=1)
        self.upd_panel.place(relx=0.5, rely=0.05, anchor="n", relwidth=0.6)

        self.upd_label = ctk.CTkLabel(self.upd_panel, text=f"New version {data['version']} available!")
        self.upd_label.pack(side="left", padx=20, pady=10)

        self.upd_btn = ctk.CTkButton(self.upd_panel, text="Update", width=80, 
                                     command=lambda: self.start_animation(data['download_url']))
        self.upd_btn.pack(side="right", padx=10, pady=10)

    def start_animation(self, url):
        # Schováme tlačítko a text, ukážeme Progress
        self.upd_btn.destroy()
        self.upd_label.configure(text="Downloading update...")
        
        self.p_bar = ctk.CTkProgressBar(self.upd_panel, width=300)
        self.p_bar.pack(pady=10, padx=20)
        self.p_bar.set(0)

        # Simulace stahování a animace baru
        def animate():
            for i in range(1, 101):
                time.sleep(0.035) # Celkem cca 3.5s
                self.p_bar.set(i / 100)
            
            # Po dokončení animace spustíme reálný proces
            updater.run_update_process(url)

        import threading
        threading.Thread(target=animate).start()

    def show_basic_page(self):
        for w in self.main_content.winfo_children(): w.destroy()
        ctk.CTkLabel(self.main_content, text="Basic Customization", font=("Arial", 22)).pack(pady=20)
        
        ctk.CTkSwitch(self.main_content, text="Center Taskbar Icons", 
                      command=lambda: tweaks.set_taskbar_alignment(True)).pack(pady=10)
        ctk.CTkButton(self.main_content, text="Clean Temp Files", 
                      command=lambda: print("Cleaning...")).pack(pady=10)

    def show_advanced_page(self):
        # Podobně jako basic...
        pass

if __name__ == "__main__":
    app = WinCustomizerApp()
    app.mainloop()