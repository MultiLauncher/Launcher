import customtkinter as ctk
import threading
import sys
import os

# Importy tvých vlastních modulů
# (Ujisti se, že máš v core/ updater.py s funkcí check_for_update)
from core import updater 

class WinCustomizerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # --- ZÁKLADNÍ NASTAVENÍ OKNA ---
        self.title("WinCustomizer Pro")
        self.geometry("1000x650")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.current_version = "1.1.0"

        # --- STRUKTURA UI (SIDEBAR A HLAVNÍ PLOCHA) ---
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Boční menu (Sidebar)
        self.sidebar = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        
        self.logo = ctk.CTkLabel(self.sidebar, text="WIN CUSTOMIZER", font=ctk.CTkFont(size=20, weight="bold"))
        self.logo.pack(pady=30, padx=20)

        self.btn_basic = ctk.CTkButton(self.sidebar, text="Basic Settings", command=lambda: self.show_page("basic"))
        self.btn_basic.pack(pady=10, padx=20)

        self.btn_adv = ctk.CTkButton(self.sidebar, text="Advanced", command=lambda: self.show_page("advanced"))
        self.btn_adv.pack(pady=10, padx=20)

        self.version_label = ctk.CTkLabel(self.sidebar, text=f"Version: {self.current_version}", font=("Arial", 10))
        self.version_label.pack(side="bottom", pady=20)

        # Hlavní kontejner pro obsah
        self.content_view = ctk.CTkFrame(self, corner_radius=15, fg_color="#1a1a1a")
        self.content_view.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

        # --- SPUŠTĚNÍ KONTROLY UPDATU ---
        # Spustíme v jiném vlákně, aby UI hned naběhlo a nesekalo se
        threading.Thread(target=self.background_update_check, daemon=True).start()

    def show_page(self, page_name):
        # Tady se bude měnit obsah podle kliknutí (zatím jen label)
        for widget in self.content_view.winfo_children():
            widget.destroy()
            
        lbl = ctk.CTkLabel(self.content_view, text=f"Welcome to {page_name.capitalize()} Tab", font=("Arial", 20))
        lbl.pack(expand=True)

    def background_update_check(self):
        """Zkontroluje update a pokud existuje, vyvolá zobrazení popupu v hlavním vlákně."""
        update_info = updater.check_for_update()
        
        # Validace: Pokud data nejsou None a mají URL
        if update_info and update_info.get("download_url") and update_info.get("version"):
            # UI změny musí běžet v hlavním vlákně přes .after()
            self.after(0, lambda: self.show_update_notification(update_info))

    def show_update_notification(self, info):
        """Vytvoří moderní popup upozornění v horní části okna."""
        self.notif_frame = ctk.CTkFrame(self, fg_color="#2b2b2b", border_color="#ff9500", border_width=2, height=60)
        self.notif_frame.place(relx=0.5, rely=0.05, anchor="n")

        msg = f"Hey there! New Update available: {info['version']}"
        lbl = ctk.CTkLabel(self.notif_frame, text=msg, font=ctk.CTkFont(weight="bold"))
        lbl.pack(side="left", padx=(20, 10), pady=10)

        btn = ctk.CTkButton(self.notif_frame, text="Update Now", width=100, height=28,
                            fg_color="#ff9500", hover_color="#cc7a00", text_color="black",
                            command=lambda: updater.run_update_process(info['download_url']))
        btn.pack(side="right", padx=10, pady=10)

        # Možnost zavřít popup křížkem (volitelné)
        close_btn = ctk.CTkButton(self.notif_frame, text="X", width=20, fg_color="transparent", 
                                  command=self.notif_frame.destroy)
        close_btn.pack(side="right", padx=5)

if __name__ == "__main__":
    app = WinCustomizerApp()
    app.mainloop()