import customtkinter as ctk
import threading
import time
import sys
from core import updater, tweaks

class WinCustomizerApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        # AKTUALNÍ VERZE APLIKACE
        self.current_version = "1.2.0" 
        
        self.title(f"WinCustomizer Pro v{self.current_version}")
        self.geometry("1000x650")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # --- SIDEBAR KONSTRUKCE ---
        self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        
        self.logo = ctk.CTkLabel(self.sidebar, text="WIN CUSTOMIZER", font=("Impact", 28), text_color="#3a7ebf")
        self.logo.pack(pady=30, padx=20)
        
        # Tlačítka menu
        self.btn_basic = ctk.CTkButton(self.sidebar, text="Basic Tweaks", corner_radius=10,
                                       command=self.show_basic)
        self.btn_basic.pack(fill="x", padx=20, pady=10)

        self.btn_extreme = ctk.CTkButton(self.sidebar, text="Extreme Mode", corner_radius=10,
                                         fg_color="#551a8b", hover_color="#3d1263",
                                         command=self.show_extreme)
        self.btn_extreme.pack(fill="x", padx=20, pady=10)

        self.v_label = ctk.CTkLabel(self.sidebar, text=f"System Version: {self.current_version}", font=("Arial", 11))
        self.v_label.pack(side="bottom", pady=20)

        # --- HLAVNÍ OBSAHOVÁ PLOCHA ---
        self.main_content = ctk.CTkFrame(self, fg_color="#111111", corner_radius=15)
        self.main_content.pack(side="right", fill="both", expand=True, padx=20, pady=20)

        # Spuštění kontroly aktualizací (za 2 sekundy po startu)
        self.after(2000, self.start_update_thread)
        
        # Výchozí stránka
        self.show_basic()

    # --- LOGIKA AKTUALIZACE ---
    def start_update_thread(self):
        t = threading.Thread(target=self.check_updates, daemon=True)
        t.start()

    def check_updates(self):
        data = updater.check_for_update(self.current_version)
        if data:
            self.after(0, lambda: self.show_update_notification(data))

    def show_update_notification(self, data):
        self.upd_panel = ctk.CTkFrame(self, fg_color="#2b2b2b", border_color="#ff9500", border_width=2)
        self.upd_panel.place(relx=0.5, rely=0.05, anchor="n", relwidth=0.7)

        self.upd_label = ctk.CTkLabel(self.upd_panel, text=f"New Update {data['version']} available!", font=("Arial", 14, "bold"))
        self.upd_label.pack(side="left", padx=20, pady=15)

        self.upd_btn = ctk.CTkButton(self.upd_panel, text="Update Now", fg_color="#ff9500", text_color="black",
                                     command=lambda: self.trigger_download(data['download_url']))
        self.upd_btn.pack(side="right", padx=20)

    def trigger_download(self, url):
        self.upd_btn.destroy()
        self.upd_label.configure(text="Downloading update package...")
        
        self.p_bar = ctk.CTkProgressBar(self.upd_panel, width=400, progress_color="#ff9500")
        self.p_bar.pack(pady=(0, 15), padx=20)
        self.p_bar.set(0)

        def run_anim():
            for i in range(1, 101):
                time.sleep(0.035)
                self.p_bar.set(i / 100)
            updater.run_update_process(url)

        threading.Thread(target=run_anim, daemon=True).start()

    # --- STRÁNKY ---
    def clear_main(self):
        for widget in self.main_content.winfo_children():
            widget.destroy()

    def show_basic(self):
        self.clear_main()
        ctk.CTkLabel(self.main_content, text="Basic Windows Customization", font=("Arial", 24, "bold")).pack(pady=30)
        
        # Přepínač pro skryté soubory
        self.sw_hidden = ctk.CTkSwitch(self.main_content, text="Show Hidden Files & Folders", 
                                       command=lambda: tweaks.toggle_hidden_files(self.sw_hidden.get()))
        self.sw_hidden.pack(pady=15)

        # Přepínač pro Taskbar
        self.sw_task = ctk.CTkSwitch(self.main_content, text="Center Taskbar Icons (Win 11)", 
                                     command=lambda: tweaks.set_taskbar_alignment(self.sw_task.get()))
        self.sw_task.pack(pady=15)

        # Tlačítko pro čištění
        ctk.CTkButton(self.main_content, text="Clean Temporary Files", 
                      fg_color="#3a7ebf", command=tweaks.cleanup_temp).pack(pady=20)

    def show_extreme(self):
        self.clear_main()
        ctk.CTkLabel(self.main_content, text="Extreme Mode - Use with Caution", font=("Arial", 24, "bold"), text_color="#ff4444").pack(pady=30)
        
        ctk.CTkButton(self.main_content, text="Create 'God Mode' Folder on Desktop", 
                      fg_color="#551a8b", hover_color="#3d1263",
                      command=tweaks.enable_god_mode).pack(pady=15)
        
        ctk.CTkButton(self.main_content, text="Set Custom Text to Taskbar Clock", 
                      command=lambda: tweaks.set_custom_clock_text("Kikin")).pack(pady=15)
        
        ctk.CTkLabel(self.main_content, text="*Changes might require Explorer restart to take full effect.", font=("Arial", 10), text_color="gray").pack(pady=20)

if __name__ == "__main__":
    app = WinCustomizerApp()
    app.mainloop()