import customtkinter as ctk
from core.tweaks import set_windows_dark_mode

class BasicSettingsFrame(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="transparent")
        
        self.label = ctk.CTkLabel(self, text="Basic Windows Settings", font=("Arial", 24))
        self.label.pack(pady=20)

        self.switch_dark = ctk.CTkSwitch(self, text="Force Windows Dark Mode", 
                                         command=lambda: set_windows_dark_mode(self.switch_dark.get()))
        self.switch_dark.pack(pady=10)

class AdvancedSettingsFrame(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="transparent")
        
        self.label = ctk.CTkLabel(self, text="Advanced Tweaks", font=("Arial", 24))
        self.label.pack(pady=20)
        
        self.btn_perf = ctk.CTkButton(self, text="Optimize Performance", fg_color="red")
        self.btn_perf.pack(pady=10)