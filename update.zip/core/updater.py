import requests
import subprocess
import os
import sys

# --- KONFIGURACE ---
# Sem vlož svůj RAW odkaz na GitHubu (verze 1.1.0 v JSONu)
VERSION_CHECK_URL = "https://raw.githubusercontent.com/MultiLauncher/Launcher/main/version.json"

def check_for_update(current_version):
    """
    Zkontroluje cloud a zjistí, zda je k dispozici novější verze.
    Vrací slovník s daty nebo None, pokud update není potřeba nebo se stala chyba.
    """
    try:
        # 1. Stažení JSONu s informacemi
        response = requests.get(VERSION_CHECK_URL, timeout=5)
        if response.status_code != 200:
            return None
        
        data = response.json()
        
        # 2. Ošetření případných None hodnot v JSONu
        remote_version = data.get("version")
        download_url = data.get("download_url")

        if not remote_version or not download_url:
            print("Update check: Missing data in JSON (None).")
            return None

        # 3. Porovnání verzí (např. "1.1.0" > "1.0.0")
        if remote_version > current_version:
            return data
            
    except Exception as e:
        print(f"Update check failed (Offline?): {e}")
    
    return None

def run_update_process(download_url):
    """
    Stáhne ZIP balíček a spustí externí worker skript pro přepsání souborů.
    """
    try:
        print("Starting download...")
        # 1. Stažení aktualizačního balíčku
        r = requests.get(download_url, timeout=30)
        zip_name = "update_package.zip"
        
        with open(zip_name, "wb") as f:
            f.write(r.content)
        
        print(f"Update downloaded as {zip_name}.")

        # 2. Spuštění updater_worker.pyw
        worker_script = "updater_worker.pyw"
        if os.path.exists(worker_script):
            # Získáme cestu k aktuálnímu pythonu (např. pythonw.exe pro skrytí konzole)
            if sys.executable.endswith("python.exe"):
                python_exec = sys.executable.replace("python.exe", "pythonw.exe")
            else:
                python_exec = sys.executable

            print("Launching worker and shutting down...")
            # Spustíme worker jako nezávislý proces
            subprocess.Popen([python_exec, worker_script], shell=False)
            
            # 3. Okamžité ukončení hlavní aplikace (aby nebyla zamknutá)
            sys.exit(0)
        else:
            print(f"Error: {worker_script} not found in root directory!")
            
    except Exception as e:
        # Pokud se něco pokazí, zapíšeme to aspoň do error logu
        with open("update_error.txt", "a") as f:
            f.write(f"Download/Launch failed: {str(e)}\n")
        print(f"Critical Update Error: {e}")