import winreg
import os
import ctypes

def toggle_taskbar_center(align_left=True):
    """Změní zarovnání ikon na taskbaru (Windows 11)."""
    path = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    value = 0 if align_left else 1 # 0 = Left, 1 = Center
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "TaskbarAl", 0, winreg.REG_DWORD, value)
        winreg.CloseKey(key)
        return True
    except: return False

def set_transparency_effects(enabled=True):
    """Zapne/vypne efekty průhlednosti ve Windows."""
    path = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
    value = 1 if enabled else 0
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "EnableTransparency", 0, winreg.REG_DWORD, value)
        winreg.CloseKey(key)
        return True
    except: return False

def cleanup_temp():
    """Rychlé promazání dočasných souborů."""
    temp_path = os.environ.get('TEMP')
    try:
        for file in os.listdir(temp_path):
            file_path = os.path.join(temp_path, file)
            if os.path.isfile(file_path):
                os.remove(file_path)
        return "Cleanup finished!"
    except: return "Some files are in use."