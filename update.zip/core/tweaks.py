import winreg
import ctypes
import os
import shutil

def set_taskbar_alignment(center=True):
    """Zarovná ikony taskbaru (Win 11). True = Střed, False = Vlevo."""
    path = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    val = 1 if center else 0
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "TaskbarAl", 0, winreg.REG_DWORD, val)
        winreg.CloseKey(key)
        return True
    except:
        return False

def toggle_hidden_files(show=True):
    """Zobrazí nebo skryje skryté soubory."""
    path = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    val = 1 if show else 2
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "Hidden", 0, winreg.REG_DWORD, val)
        winreg.CloseKey(key)
        return True
    except:
        return False

def cleanup_temp():
    """Smaže dočasné soubory."""
    temp_path = os.environ.get('TEMP')
    for file in os.listdir(temp_path):
        try:
            full_path = os.path.join(temp_path, file)
            if os.path.isfile(full_path): os.remove(full_path)
            elif os.path.isdir(full_path): shutil.rmtree(full_path)
        except:
            continue

def enable_god_mode():
    """Vytvoří God Mode na ploše."""
    desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
    path = os.path.join(desktop, "GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}")
    if not os.path.exists(path):
        os.makedirs(path)

def set_custom_clock_text(text):
    """Přidá text k hodinám."""
    path = r"Control Panel\International"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "sShortTime", 0, winreg.REG_SZ, f"HH:mm '{text}'")
        winreg.CloseKey(key)
        ctypes.windll.user32.SendMessageW(0xFFFF, 0x001A, 0, 0)
    except:
        pass