import time
import os
import zipfile
import subprocess
import sys
import shutil

# Jméno tvého ZIPu (ujisti se, že updater.py ho stahuje pod tímto názvem)
ZIP_NAME = "update_package.zip"
MAIN_SCRIPT = "main.py"

def kill_main_process():
    """Pokusí se ukončit proces, pokud by náhodou ještě visel v systému."""
    if os.name == 'nt': # Windows
        try:
            # Vynucené ukončení všech běžících python procesů, co drží main.py
            os.system(f"taskkill /f /im python.exe /t")
            os.system(f"taskkill /f /im pythonw.exe /t")
        except:
            pass

def run_extraction():
    time.sleep(3) # Čas na zavření oken
    
    try:
        if os.path.exists(ZIP_NAME):
            # 1. Rozbalení
            with zipfile.ZipFile(ZIP_NAME, 'r') as zip_ref:
                # Projdeme soubory v zipu a extrahujeme je jeden po druhém
                # Tím lépe uvidíme, kde to případně selže
                for member in zip_ref.namelist():
                    try:
                        zip_ref.extract(member, ".")
                    except Exception as e:
                        print(f"Chyba při extrakci {member}: {e}")

            # 2. Úklid - Smažeme balíček, aby to bylo čisté
            time.sleep(1)
            os.remove(ZIP_NAME)
            
            # 3. Restart aplikace
            if os.path.exists(MAIN_SCRIPT):
                subprocess.Popen([sys.executable, MAIN_SCRIPT])
        else:
            with open("error_log.txt", "a") as f:
                f.write("ZIP nebyl nalezen ve slozce.\n")
                
    except Exception as e:
        with open("error_log.txt", "a") as f:
            f.write(f"Kriticka chyba: {str(e)}\n")

if __name__ == "__main__":
    # kill_main_process() # Tuhle řádku odkomentuj jen pokud update stále selhává
    run_extraction()
    sys.exit()